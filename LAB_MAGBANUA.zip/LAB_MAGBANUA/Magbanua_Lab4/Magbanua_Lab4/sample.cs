﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4_HannahReyes
{
    class sample
    {
        static sample()
        {
            System.Console.WriteLine("\n\nStatic Constructor");
        }

        public sample(double part1, double part2, double part3, double part4, double part5, double ave)
        {
            Console.WriteLine("Average = " + ave);
        }
    }
}
