﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Magbanua_Lab4
{
    class Program
    {
        static void Main(string[] args)
        {
            double part1, part2, part3, part4, part5, ave;

            Console.WriteLine("Enter 5 numbers");
            part1 = Convert.ToDouble(Console.ReadLine());
            part2 = Convert.ToDouble(Console.ReadLine());
            part3 = Convert.ToDouble(Console.ReadLine());
            part4 = Convert.ToDouble(Console.ReadLine());
            part5 = Convert.ToDouble(Console.ReadLine());

            ave = (part1 + part2 + part3 + part4 + part5) / 5;

            sample numbers = new sample(part1, part2, part3, part4, part5, ave);
            Console.ReadLine();

        }
    }

   
        }