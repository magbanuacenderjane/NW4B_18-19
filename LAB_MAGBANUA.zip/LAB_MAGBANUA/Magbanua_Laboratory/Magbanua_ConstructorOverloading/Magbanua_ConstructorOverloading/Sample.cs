﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Magbanua_ConstructorOverloading
{
    class Sample
    {
        public string fname, mname, lname;
        public Sample()
        {
            fname = "Cenderjane";
            mname = "Zaballero";
            lname = "Magbanua"; 
            
        }
        public Sample (string x, string y, string z)
        {
            fname = x;
            mname = y;
            lname = z;
        }
    }
}
