﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Magbanua_ConstructorOverloading
{
    class Program
    {
        static void Main(string[] args)
        {
            Sample name = new Sample();
            Sample name1 = new Sample("Cenderjane", " Zaballero", "Magbanua");
            Console.WriteLine(name.fname + " " + name.mname + " " + name.lname);
            Console.WriteLine(name1.fname + " " + name1.mname + " " + name1.lname);
            Console.ReadLine();
        }
    }
}
