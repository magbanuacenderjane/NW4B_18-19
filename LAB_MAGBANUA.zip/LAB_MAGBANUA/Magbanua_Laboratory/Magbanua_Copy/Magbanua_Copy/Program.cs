﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Magbanua_Copy
{
    class Program
    {
        static void Main(string[] args)
        {
            Sample name = new Sample("Cenderjane", "Zaballero", "Magbanua");
            Sample name1 = new Sample(name);
            Console.WriteLine(name);
            Console.WriteLine("\n" + name1.fname + "\n" +name1.mname+ "\n" +name1.lname);
            Console.ReadLine();
        }
    }
}
