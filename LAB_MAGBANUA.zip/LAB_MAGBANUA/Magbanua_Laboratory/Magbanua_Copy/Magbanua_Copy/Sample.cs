﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Magbanua_Copy
{
    class Sample
    {
        public string fname, mname, lname;
        public Sample (string x, string y, string z)
        {
            fname = x;
            mname = y;
            lname = z;
        }
        public Sample (Sample name)
        {
            fname = name.fname;
            mname = name.mname;
            lname = name.mname;

        }
    }
}
