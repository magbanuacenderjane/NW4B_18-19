﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Magbanua_Default
{
    class Sample
    {
        public string fname, lname;
        public Sample()
        {
            fname = "Cenderjane";
            lname = "Magbanua";
        }
    }
}
