﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Magbanua_Parameterized
{
    class Program
    {
        static void Main(string[] args)
        {
            Sample name = new Sample("Cenderjane", "Zaballero", "Magbanua");
            Console.WriteLine(name.fname);
            Console.WriteLine(name.mname);
            Console.WriteLine(name.lname);
            Console.ReadLine();
        }
    }
}
