﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_Static
{
    class Program
    {
        static void Main(string[] args)
        {
            Sample name = new Sample();
            Sample name1 = new Sample();
            Console.WriteLine(name.fname + " " + " " + name.mname + " " + name.lname);
            Console.ReadLine();
      
        }
    }
}
