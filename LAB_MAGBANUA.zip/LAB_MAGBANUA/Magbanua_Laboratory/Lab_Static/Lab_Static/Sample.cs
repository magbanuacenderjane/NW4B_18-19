﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_Static
{
    class Sample
    {
        public string fname, mname, lname;

        static Sample()
        {
            Console.WriteLine("Static Constructor.");

        }
        public Sample()
        {
            fname = " Cenderjane";
            mname = " Zaballero";
            lname = " Magbanua";
        }

    }
}