﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Magbanua_Private
{
    class Sample
    {
        public string fname, mname, lname;
        public Sample (string x, string y ,string z)
        {
            fname = x;
            mname = y;
            lname = z;
        }
        private Sample()
        {
            Console.WriteLine("Private Construvtor");
        }
            }
}
